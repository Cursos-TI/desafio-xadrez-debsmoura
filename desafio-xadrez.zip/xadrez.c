#include <stdio.h>

int main() {
    printf("Bem-vindo ao Desafio Xadrez!\n");
    // Código exemplo de lógica de xadrez aqui
    return 0;
}
