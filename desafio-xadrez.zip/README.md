# Desafio Xadrez - Estácio

Este é o repositório do Desafio Xadrez solicitado pela disciplina de programação.

## Objetivo

Implementar um programa simples em C que simule um ambiente básico relacionado ao xadrez.

## Como executar

Compile com:
```
gcc xadrez.c -o xadrez
./xadrez
```

## Autora

Débora
